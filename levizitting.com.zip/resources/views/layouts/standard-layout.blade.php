@extends("layouts.master")

@section("main")
    @yield("content")
@endsection