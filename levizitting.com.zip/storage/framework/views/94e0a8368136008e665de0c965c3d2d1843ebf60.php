<?php $__env->startSection("content"); ?>
    <div class="container">
        <div class="row">
            <div class="col m10 offset-m1 s12 offset-s0">
                <?php $__currentLoopData = $projects->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chuckedProjects): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <?php $__currentLoopData = $chuckedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col m6 s12">
                                <div class="project" style="background-image: url('/images/projects/<?php echo e($project->image); ?>');">
                                    <div class="dark-panel" tabindex="0">
                                        <div class="title">
                                            <h4><?php echo e($project->title); ?></h4>
                                        </div>
                                        <div class="body">
                                            <?php echo $project->body; ?>

                                        </div>
                                    </div>
                                    <i class="material-icons arrow-icon" aria-hidden="true">arrow_upward</i>
                                    <div class="un-focuser" tabindex="0"></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.standard-layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>