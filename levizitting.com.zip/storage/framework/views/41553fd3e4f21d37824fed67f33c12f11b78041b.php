<?php $__env->startSection("content"); ?>
    <div class="container">
        <div class="row card">
            <h1 class="center-align">Edit Post</h1>
            <form class="col s12" method="POST" action="/admin/posts/<?php echo e($post->slug); ?>/edit" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="input-field col s12">
                    <input class="validate" id="title" type="text" value="<?php echo e($post->title); ?>" name="title">
                    <label for="title">Title</label>
                </div>
                <div class="file-field input-field col s12">
                    <div class="btn"><span>Featured Image</span>
                        <input type="file" name="file">
                    </div>
                    <div class="file-path-wrapper">
                        <input class="file-path validate" type="text" value="<?php echo e($post->image); ?>" name="image">
                    </div>
                </div>
                <div class="input-field col s12">
                    <textarea class="materialize-textarea validate" id="body" name="body"><?php echo e($post->body); ?></textarea>
                    <label for="body">Body</label>
                </div>
                <input class="btn waves-effect right" type="submit" value="Update">
            </form>
            <form method="POST" action="/admin/posts/<?php echo e($post->slug); ?>/delete" id="delete-item">
                <?php echo e(csrf_field()); ?>

                <input class="btn waves-effect red" type="submit" value="Delete">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>