<?php $__env->startSection("content"); ?>
    <div class="container">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <h1 class="center-align">Manage Projects</h1><a class="btn waves-effect" id="new-post" href="/admin/projects/create">New Project</a>
                    <table class="display" id="projects-table">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Published</th>
                            <th> </th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($project->id); ?></td>
                                <td><?php echo e($project->title); ?></td>
                                <td><?php echo e($project->created_at); ?></td>
                                <td><a class="btn waves-effect" href="/admin/projects/<?php echo e($project->id); ?>/edit">Edit</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>