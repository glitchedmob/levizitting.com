<?php $__env->startSection("content"); ?>
    <div class="col s12 m8 posts">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card large post">
                <div class="card-image"><img src="/images/blog/<?php echo e($post->image); ?>"></div>
                <div class="card-content"><span class="card-title"><?php echo e($post->title); ?></span>
                    <p class="post-meta"><span class="published">Published: </span> <?php echo e($post->created_at->toFormattedDateString()); ?> </p>
                    <p class="post-body flow-text"><?php echo e(substr(strip_tags($post->body), 0, 100).'...'); ?></p>
                    <div class="read-more"><a class="btn waves-effect" href="/blog/<?php echo e($post->slug); ?>">Read More...</a></div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
            
            
            
            
            
            
            
        
        <?php echo e($posts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.blog-layout", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>