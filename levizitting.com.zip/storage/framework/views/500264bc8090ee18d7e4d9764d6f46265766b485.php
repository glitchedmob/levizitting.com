<?php $__env->startSection("main"); ?>
    <div class="container">
        <div class="row blog-move-down">
            <?php echo $__env->yieldContent("content"); ?>

            <?php echo $__env->make("layouts.sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>